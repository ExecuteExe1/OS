#! /bin/bash

current_date=$(date)
 echo "Today's date is: $current_date"

current_user='fotekokk'
echo "Current User: $current_user"

file_count=$(ls -1 $(pwd) | wc -l)
echo "Number of files in the current directory: $file_count"
