#! /bin/bash

for i in {1..5}; do
  echo "Number: $i"
 done


for color in red green blue; do
  echo "Color: $color"
done

for file in /fotekokk/Lab2/*; do
  echo "File: $file"
done
