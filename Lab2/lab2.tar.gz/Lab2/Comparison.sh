#! /bin/bash

number=10

if [ $number -gt 5 ]; then
  echo "$number is greater tha 5"
fi

name= "Alice"

if [ "$name" == "Alice" ]; then
  echo"Hello Alice"
fi
if [ "$name" != "Bob" ]; then
  echo "You are not Bob."
fi
