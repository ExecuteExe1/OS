#! /bin/bash

number=5
echo $number 
let number=number+number
echo $number

