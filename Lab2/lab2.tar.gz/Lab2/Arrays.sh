#! /bin/bash

fruits=("apple" "banana" "cherry")
echo "First fruit: ${fruits[0]}"

fruits+=("date")
for fruit in "${fruits[@]}"; do
 echo "Fruit: $fruit"
done
echo "Total fruits: ${#fruits[@]}"
